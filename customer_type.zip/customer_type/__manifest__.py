{
    'name': "Customer Type ",
    'version': '17.0.1.0.0',
    'depends': ['base'],
    'author': "Hiba",
    'category': 'Category',
    'description': "Customer",
    'data': [
   # 'security/res_groups.xml',
        'security/ir.model.access.csv',
        'views/customer_type_view.xml',
         # 'views/res_config_views.xml'


    ]

}