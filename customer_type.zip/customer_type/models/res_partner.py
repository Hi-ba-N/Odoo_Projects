from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'

    customer_rec_id = fields.Many2one('customer.type','customer Record')

    # @api.depends(customer_rec_id)
    # def check_records(self):
        # records = self.env['res.config.settings'].search(
        #     [('customer_type_id', '=', )])




