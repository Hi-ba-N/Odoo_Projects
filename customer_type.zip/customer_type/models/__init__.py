from . import customer_type
from . import res_config_setting