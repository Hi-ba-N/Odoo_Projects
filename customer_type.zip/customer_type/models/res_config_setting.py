# -*- coding: utf-8 -*-
from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'c'

    customer_type_id = fields.Many2one('customer.type', string='Customer Type',
                                       config_parameter='customer_type.customer_type_id')
