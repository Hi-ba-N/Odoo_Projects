# coding: utf-8
from odoo import fields, models


class CustomerType(models.Model):
    """This is used for student class"""
    _name = "customer.type"
    _description = "Customer Type"

    name = fields.Char("Name")
