{
    'name': "Contact ",
    'version': '17.0.1.0.0',
    'depends': ['base','sale','contacts','hr'],
    'author': "Hiba",
    'category': 'Category',
    'description': "Contact",
    'data': [
        'views/res_partner_views.xml',
    ]

}